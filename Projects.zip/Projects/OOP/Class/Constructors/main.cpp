// C++ program to demonstrate constructors
#include <iostream>

using namespace std;

class MyClass
{
    public:
    int id;

    //Default Constructor
    MyClass()
    {
        cout << "Default Constructor called" << endl;
        id=-1;
    }

    //Parameterized Constructor
    MyClass(int x)
    {
        cout <<"Parameterized Constructor called "<< endl;
        id=x;
    }
};

int main() {

    // obj1 will call Default Constructor
    MyClass obj1;
    cout <<"Class id is: "<<obj1.id << endl;

    // obj2 will call Parameterized Constructor
    MyClass obj2(21);
    cout <<"Class id is: " <<obj2.id << endl;
    return 0;
}
