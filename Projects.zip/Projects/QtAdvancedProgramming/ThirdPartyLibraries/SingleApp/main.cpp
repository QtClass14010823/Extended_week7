﻿#include <QCoreApplication>
#include "qtsinglecoreapplication.h"

#include <iostream>

using namespace std;

class MainClass : public QObject
{
    Q_OBJECT
public:
    MainClass() : QObject() {}

public slots:
    void handleMessage(const QString& message)
    {
        cout << "Message received: \"" << message.toStdString() << "\"" << endl;
    }
};

int main(int argc, char *argv[])
{
    QtSingleCoreApplication app(argc, argv);

    if (app.isRunning())
    {
        QString msg(QString("Another instance is running, pid: %1.").arg(QCoreApplication::applicationPid()));
        bool result = app.sendMessage(msg, 2000);
        QString rep("Another instance is running, so I will exit.");

        cout << (result ? "Message sent ok." : "Message sending failed; the other instance may be frozen.") << endl;

        return 0;
    }
    else
    {
        QString msg(QString("Main instance is running, pid: %1.").arg(QCoreApplication::applicationPid()));

        cout << msg.toStdString() << endl;

        MainClass mainObj;
        QObject::connect(&app, SIGNAL(messageReceived(const QString&)),
                         &mainObj, SLOT(handleMessage(const QString&)));

        return app.exec();
    }
}

#include "main.moc"
