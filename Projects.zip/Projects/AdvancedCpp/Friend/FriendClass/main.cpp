// C++ Program to demonstrate the
// functioning of a friend class
#include <iostream>
using namespace std;

class G {
private:
    int private_variable;

protected:
    int protected_variable;

public:
    G()
    {
        private_variable = 10;
        protected_variable = 99;
    }

    // friend class declaration
    friend class F;
};

// Here, class F is declared as a
// friend inside class G. Therefore,
// F is a friend of class G. Class F
// can access the private members of
// class G.
class F {
public:
    void display(G& t)
    {
        cout << "The value of Private Variable = "
            << t.private_variable << endl;
        cout << "The value of Protected Variable = "
            << t.protected_variable << endl;
    }
};

// Driver code
int main()
{
    G g;
    F fri;
    fri.display(g);
    return 0;
}
